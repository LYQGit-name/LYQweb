var target = document.getElementById("submit");
target.onclick = function () {
    alert("我被点击了啊")
}